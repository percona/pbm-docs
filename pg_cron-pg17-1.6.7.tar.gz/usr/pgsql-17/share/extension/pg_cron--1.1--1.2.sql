/* pg_cron--1.1--1.2.sql */

SELECT pg_catalog.pg_extension_config_dump('cron.job', '');
SELECT pg_catalog.pg_extension_config_dump('cron.jobid_seq', '');
